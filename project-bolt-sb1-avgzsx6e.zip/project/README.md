# 🏰 Rise of Kingdoms Title Management Bot

A comprehensive Discord bot that **fully automates** the assignment, rotation, and queue management of Rise of Kingdoms (RoK) kingdom titles. **Zero admin intervention required** - the bot handles everything automatically from request to assignment to rotation.

## ✨ Features

### 🎯 Core Functionality
- **🤖 Fully Automated**: Zero admin intervention - everything happens automatically
- **🧠 Smart Message Parsing**: Understands natural language requests in multiple formats
- **⚡ Instant Assignment**: Immediately assigns available titles or adds to queue
- **📋 Queue Management**: Manages waiting lists with position tracking and wait time estimates  
- **🔄 Auto-Reassignment**: Automatically moves titles to the next person in queue when they expire
- **📱 Real-time Notifications**: Keeps users informed about assignments, queue position, and wait times

### 🛡️ Advanced Features
- **🛡️ Anti-spam Protection**: User cooldowns prevent request spam
- **🎮 Instant Activation**: Titles are immediately active - no waiting for manual assignment
- **⏱️ Flexible Duration**: Support for custom title durations (5-180 minutes)
- **🏰 Multiple Title Support**: Manages all common RoK titles simultaneously
- **📍 Coordinate Validation**: Ensures valid RoK map coordinates
- **🔄 Seamless Rotation**: Automatic handoff between users with notifications

### 💬 Supported Message Formats
The bot understands requests in various natural language formats:

```
Can I get Scientist at 1234 567 for 15 minutes?
Need General for 20m – coords 1045 899  
Requesting Architect x:1100 y:1180 10 min
Scientist 1234, 567 15m
coords: 1234 567 Economist 30 minutes
```

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ 
- Discord bot token
- Discord server with appropriate permissions

### Installation

1. **Clone and Install**
```bash
git clone <repository-url>
cd rok-title-bot
npm install
```

2. **Environment Setup**
```bash
cp .env.example .env
```

3. **Configure Environment**
Edit `.env` with your bot credentials:
```env
DISCORD_TOKEN=your_bot_token_here
TITLE_REQUEST_CHANNEL_ID=your_channel_id_here
GUILD_ID=your_server_id_here
```

4. **Start the Bot**
```bash
npm start
```

## 🎮 Usage

### For Players

**Request a Title:**
Simply type a message in the designated channel:
```
Can I get Scientist at 1234 567 for 20 minutes?
```

**Check Status:**
```
/status
/status Scientist
```

**View Queue:**
```
/queue Scientist
```

**Leave Queue:**
```
/remove
/remove Scientist
```

### For Administrators

**Force Assign Title:**
```
/force-assign title:Scientist user:@username coordinates:1234, 567 duration:30
```

**Mark Title as Assigned In-Game:**
```
/mark-assigned title:Scientist
```

**Get Assignment Instructions:**
```
/assignment-guide title:Scientist
```

**View Pending Assignments:**
```
/pending-assignments
```

## 📋 Available Titles

- Scientist
- Architect  
- General
- Duke
- Prime Minister
- Foreign Minister
- Interior Minister
- Agriculture Minister
- Economist
- Chief of Staff
- Messenger
- Strategist

## ⚙️ Configuration

### Basic Settings (`src/config/config.js`)
```javascript
{
  defaultTitleDuration: 15,    // Default minutes
  maxTitleDuration: 180,       // Max 3 hours
  minTitleDuration: 5,         // Min 5 minutes
  maxQueueSize: 10,            // Max users per queue
  userCooldownMinutes: 5       // Cooldown between requests
}
```

### Permissions
Configure admin roles and users in the config file:
```javascript
permissions: {
  adminRoles: ['role_id_here'],
  superAdmins: ['user_id_here']
}
```

## 🏗️ Project Structure

```
src/
├── index.js              # Main bot file
├── managers/
│   └── TitleManager.js   # Core title assignment logic
├── utils/
│   └── MessageParser.js  # Natural language parsing
├── commands/             # Slash commands
│   ├── status.js
│   ├── queue.js
│   ├── remove.js
│   ├── force-assign.js
│   └── help.js
└── config/
    └── config.js         # Bot configuration
```

## 🔧 Development

### Running in Development
```bash
npm run dev
```

### Testing Message Parser
```javascript
const MessageParser = require('./src/utils/MessageParser');
const parser = new MessageParser();

// Test different message formats
parser.testParse("Can I get Scientist at 1234 567 for 15 minutes?");
parser.testParse("Need General coords 1045, 899 for 20m");
```

## 📊 Bot Commands

| Command | Description | Permissions |
|---------|-------------|-------------|
| `/status` | View all title status | Everyone |
| `/status [title]` | Check specific title | Everyone |
| `/queue [title]` | View title queue | Everyone |
| `/remove` | Leave all queues | Everyone |
| `/remove [title]` | Leave specific queue | Everyone |  
| `/force-assign` | Force assign title | Admin |
| `/mark-assigned` | Confirm in-game assignment | Admin |
| `/assignment-guide` | Get assignment steps | Everyone |
| `/pending-assignments` | View pending assignments | Admin |
| `/help` | Show help guide | Everyone |

## 💰 Monetization Ready

This bot is designed with hosting services in mind:
- **Clean Architecture**: Easy to deploy and scale
- **Configuration-driven**: Simple setup for multiple servers
- **Resource Efficient**: Minimal memory and CPU usage
- **Database Ready**: Can be extended with persistent storage
- **Multi-server Support**: Can manage multiple Discord servers

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable  
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For setup help or feature requests:
1. Check the `/help` command in Discord
2. Review this README
3. Open an issue on GitHub

## 🔮 Roadmap

- [ ] Database persistence (PostgreSQL/MongoDB)
- [ ] Web dashboard for management
- [ ] Statistics and analytics
- [ ] Multi-language support
- [ ] Integration with RoK APIs
- [ ] Advanced scheduling features
- [ ] Custom title creation
- [ ] Alliance-wide title sharing

---

**Made for Rise of Kingdoms players by RoK players** 🏰