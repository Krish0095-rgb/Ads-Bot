# 🚀 RoK Title Bot Deployment Guide

This guide covers multiple deployment options for the Rise of Kingdoms Title Bot, from development to production hosting.

## 📋 Prerequisites

- Node.js 16+ installed locally
- Discord bot token from [Discord Developer Portal](https://discord.com/developers/applications)
- Discord server with Administrator permissions

## 🔧 Local Development Setup

### 1. Initial Setup
```bash
# Clone the repository
git clone <repository-url>
cd rok-title-bot

# Install dependencies
npm install

# Copy environment template
cp .env.example .env
```

### 2. Discord Bot Setup

1. **Create Discord Application:**
   - Go to [Discord Developer Portal](https://discord.com/developers/applications)
   - Click "New Application" 
   - Name it "RoK Title Bot"

2. **Create Bot:**
   - Go to "Bot" section
   - Click "Add Bot"
   - Copy the bot token

3. **Set Bot Permissions:**
   - In "OAuth2 > URL Generator"
   - Select "bot" and "applications.commands" scopes
   - Select these permissions:
     - Send Messages
     - Use Slash Commands
     - Read Message History
     - Embed Links
     - Add Reactions

4. **Invite Bot to Server:**
   - Use the generated URL to invite the bot
   - Ensure it has access to your title request channel

### 3. Configuration

Edit your `.env` file:
```env
# Required
DISCORD_TOKEN=your_bot_token_here
TITLE_REQUEST_CHANNEL_ID=123456789012345678
GUILD_ID=123456789012345678

# Optional  
BOT_PREFIX=!
MAX_QUEUE_SIZE=10
DEFAULT_TITLE_DURATION=15
```

**Getting Channel/Server IDs:**
1. Enable Developer Mode in Discord (User Settings > Advanced)
2. Right-click channel/server → Copy ID

### 4. Run Locally
```bash
# Development with auto-restart
npm run dev

# Production mode
npm start
```

## ☁️ Cloud Hosting Options

### Option 1: Railway (Recommended)

**Pros:** Simple deployment, generous free tier, automatic deployments
**Cost:** Free tier available, then ~$5/month

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway init
railway add
railway up
```

**Environment Variables in Railway:**
```
DISCORD_TOKEN=your_token
TITLE_REQUEST_CHANNEL_ID=your_channel_id
GUILD_ID=your_guild_id
```

### Option 2: Heroku

**Pros:** Established platform, good documentation
**Cost:** ~$7/month (no free tier as of 2022)

1. **Create Heroku Account:** [heroku.com](https://heroku.com)

2. **Install Heroku CLI:**
```bash
# Deploy to Heroku
heroku create rok-title-bot
heroku config:set DISCORD_TOKEN=your_token
heroku config:set TITLE_REQUEST_CHANNEL_ID=your_channel_id
git push heroku main
```

3. **Keep Bot Running:**
```bash
heroku ps:scale worker=1
```

### Option 3: DigitalOcean App Platform

**Pros:** Good performance, reasonable pricing
**Cost:** ~$5/month

1. Fork the repository to GitHub
2. Connect DigitalOcean to your GitHub
3. Create new app from repository
4. Add environment variables
5. Deploy

### Option 4: VPS (Advanced)

**Pros:** Full control, can host multiple bots
**Cost:** ~$5-10/month

**Providers:** DigitalOcean, Linode, Vultr, AWS EC2

```bash
# Basic VPS setup (Ubuntu)
sudo apt update
sudo apt install nodejs npm git pm2

# Clone and setup
git clone <your-repo>
cd rok-title-bot
npm install

# Start with PM2 (process manager)
pm2 start src/index.js --name "rok-bot"
pm2 save
pm2 startup
```

## 🗄️ Database Integration (Optional)

For persistent data storage across restarts:

### Option 1: SQLite (Simple)
```javascript
// Add to package.json
"sqlite3": "^5.1.6"

// Basic implementation
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('titles.db');
```

### Option 2: PostgreSQL (Production)
```javascript
// Add to package.json  
"pg": "^8.8.0"

// Use with cloud providers:
// - Railway PostgreSQL
// - Heroku Postgres
// - Supabase
```

## 📊 Monitoring & Logging

### Basic Logging
```javascript
// In src/index.js
console.log(`Bot started at ${new Date()}`);
console.log(`Monitoring channel: ${process.env.TITLE_REQUEST_CHANNEL_ID}`);

// Log all title requests
console.log(`Title request: ${title} by ${username}`);
```

### Advanced Monitoring
```bash
# Add monitoring packages
npm install winston discord-webhook-node

# Health check endpoint for uptime monitoring
npm install express
```

## 🔒 Security Best Practices

### Environment Variables
```bash
# Never commit .env files
echo ".env" >> .gitignore

# Use secure token storage
# Rotate tokens regularly
# Use read-only database credentials when possible
```

### Bot Permissions
- Grant minimum required permissions
- Use role-based access control
- Monitor bot activity logs

## 🚀 Production Checklist

- [ ] Environment variables configured
- [ ] Bot invited to server with correct permissions
- [ ] Title request channel ID set correctly
- [ ] Admin roles configured in config.js
- [ ] Error handling and logging implemented
- [ ] Health monitoring setup
- [ ] Backup strategy for data (if using database)
- [ ] Domain name setup (if applicable)
- [ ] SSL certificate (for web interface)

## 💰 Monetization Setup

### Multi-Server Support
```javascript
// Modify config to support multiple servers
const serverConfigs = {
  'server1_id': {
    titleChannel: 'channel_id',
    adminRoles: ['role_id']
  },
  'server2_id': {
    titleChannel: 'different_channel_id', 
    adminRoles: ['different_role_id']
  }
};
```

### Subscription Management
```javascript
// Add premium features
const premiumFeatures = {
  maxQueueSize: 20,        // vs 10 for free
  customTitles: true,      // vs predefined only
  statistics: true,        // vs basic only
  prioritySupport: true
};
```

### Payment Integration
```javascript
// Add Stripe or PayPal
npm install stripe discord-webhook-node

// Subscription verification
const verifySubscription = async (guildId) => {
  // Check payment status
  // Enable/disable features accordingly
};
```

## 🛠️ Troubleshooting

### Common Issues

**Bot Not Responding:**
```bash
# Check bot token
# Verify channel permissions
# Check bot online status
# Review console errors
```

**Commands Not Working:**
```bash
# Re-register slash commands
# Check bot permissions
# Verify guild ID
```

**Queue Not Processing:**
```bash
# Check timer functions
# Verify message parsing
# Review queue logic
```

### Debug Mode
```javascript
// Add debug logging
const DEBUG = process.env.DEBUG === 'true';
if (DEBUG) console.log('Debug info:', data);
```

## 📞 Support

For deployment issues:
1. Check bot logs/console output
2. Verify all environment variables
3. Test with `/help` command
4. Check Discord bot permissions
5. Review this deployment guide

## 🔄 Updates and Maintenance

```bash
# Update dependencies
npm update

# Deploy updates
git push heroku main  # Heroku
railway up           # Railway

# Monitor for issues
# Test major features after updates
# Keep backups of working configurations
```

---

**Happy Deploying!** 🚀 Your RoK Title Bot will be managing kingdoms efficiently in no time!