const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config/config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('assignment-guide')
        .setDescription('Get step-by-step instructions for assigning titles in-game')
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Title to get assignment instructions for')
                .setRequired(true)
                .addChoices(
                    ...config.availableTitles.map(title => ({ name: title, value: title }))
                )
        ),

    async execute(interaction, titleManager) {
        const titleName = interaction.options.getString('title');
        const instructions = titleManager.getAssignmentInstructions(titleName);

        if (!instructions) {
            return await interaction.reply({ 
                content: `❌ No active assignment found for ${titleName}`, 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setColor(config.colors.info)
            .setTitle(`🎮 ${titleName} Assignment Guide`)
            .setDescription('Follow these steps to assign the title in Rise of Kingdoms')
            .addFields(
                { name: '👤 Governor', value: instructions.username, inline: true },
                { name: '📍 Coordinates', value: instructions.coordinates, inline: true },
                { name: '⏱️ Duration', value: `${instructions.duration} minutes`, inline: true }
            )
            .addFields({
                name: '📋 Step-by-Step Instructions',
                value: instructions.steps.join('\n'),
                inline: false
            })
            .addFields({
                name: '⚠️ Important Notes',
                value: '• Make sure you\'re at the correct coordinates\n' +
                       '• Double-check the governor name spelling\n' +
                       '• Set the exact duration specified\n' +
                       '• Use `/mark-assigned` after completing assignment',
                inline: false
            })
            .addFields({
                name: '🔄 After Assignment',
                value: `Use \`/mark-assigned ${titleName}\` to confirm the title is active in-game`,
                inline: false
            })
            .setFooter({ text: 'This ensures accurate tracking and user notifications' })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};