const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config/config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('force-assign')
        .setDescription('[ADMIN] Force assign a title to a user')
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Title to assign')
                .setRequired(true)
                .addChoices(
                    ...config.availableTitles.map(title => ({ name: title, value: title }))
                )
        )
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to assign title to')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('coordinates')
                .setDescription('Coordinates (format: x, y)')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName('duration')
                .setDescription('Duration in minutes')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(180)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction, titleManager) {
        // Check if user has admin permissions
        const hasAdminRole = interaction.member.roles.cache.some(role => 
            config.permissions.adminRoles.includes(role.id)
        );
        const isSuperAdmin = config.permissions.superAdmins.includes(interaction.user.id);
        const hasDiscordAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);

        if (!hasAdminRole && !isSuperAdmin && !hasDiscordAdmin) {
            return await interaction.reply({ 
                content: config.messages.noPermission, 
                ephemeral: true 
            });
        }

        const titleName = interaction.options.getString('title');
        const targetUser = interaction.options.getUser('user');
        const coordinates = interaction.options.getString('coordinates');
        const duration = interaction.options.getInteger('duration');

        // Validate coordinates format
        const coordMatch = coordinates.match(/^(\d{1,4}),?\s*(\d{1,4})$/);
        if (!coordMatch) {
            return await interaction.reply({ 
                content: '❌ Invalid coordinates format. Use: x, y (e.g., 1234, 567)', 
                ephemeral: true 
            });
        }

        const formattedCoords = `${coordMatch[1]}, ${coordMatch[2]}`;

        try {
            // Force assign the title
            const success = titleManager.forceAssignTitle(
                titleName, 
                targetUser.id, 
                targetUser.username, 
                formattedCoords, 
                duration
            );

            if (success) {
                const embed = new EmbedBuilder()
                    .setColor(config.colors.success)
                    .setTitle('👑 Force Assignment Complete')
                    .setDescription(`**${titleName}** has been force assigned`)
                    .addFields(
                        { name: 'Assigned To', value: `<@${targetUser.id}>`, inline: true },
                        { name: 'Coordinates', value: formattedCoords, inline: true },
                        { name: 'Duration', value: `${duration} minutes`, inline: true },
                        { name: 'Assigned By', value: `<@${interaction.user.id}>`, inline: true }
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });

                // Log the force assignment
                console.log(`🔧 FORCE ASSIGN: ${titleName} assigned to ${targetUser.username} by ${interaction.user.username}`);
            } else {
                await interaction.reply({ 
                    content: '❌ Failed to force assign title. Please try again.', 
                    ephemeral: true 
                });
            }
        } catch (error) {
            console.error('Force assign error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while force assigning the title.', 
                ephemeral: true 
            });
        }
    }
};