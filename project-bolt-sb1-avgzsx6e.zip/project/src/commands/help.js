const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config/config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Get help with using the RoK Title Bot'),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor(config.colors.info)
            .setTitle('🏰 RoK Title Bot - Help Guide')
            .setDescription('Automated Rise of Kingdoms title management system')
            .addFields(
                {
                    name: '📝 **Requesting Titles**',
                    value: 'Send a message in the title request channel using these formats:\n' +
                           '• `Can I get Scientist at 1234 567 for 15 minutes?`\n' +
                           '• `Need General for 20m – coords 1045 899`\n' +
                           '• `Requesting Architect x:1100 y:1180 10 min`\n' +
                           '• `Scientist 1234, 567 15m`',
                    inline: false
                },
                {
                    name: '🏷️ **Available Titles**',
                    value: config.availableTitles.slice(0, 6).join(', ') + 
                           (config.availableTitles.length > 6 ? `, +${config.availableTitles.length - 6} more` : ''),
                    inline: false
                },
                {
                    name: '⏰ **Duration Rules**',
                    value: `• Minimum: ${config.minTitleDuration} minutes\n` +
                           `• Maximum: ${config.maxTitleDuration} minutes\n` +
                           `• Default: ${config.defaultTitleDuration} minutes (if not specified)`,
                    inline: true
                },
                {
                    name: '🔄 **Queue System**',
                    value: `• Max ${config.maxQueueSize} users per title\n` +
                           '• Fully automatic assignment and rotation\n' +
                           '• Real-time notifications\n' +
                           '• Zero admin intervention required',
                    inline: true
                },
                {
                    name: '📍 **Coordinates**',
                    value: 'Accepted formats:\n' +
                           '• `x:1234 y:567`\n' +
                           '• `1234 567`\n' +
                           '• `coords 1234, 567`',
                    inline: false
                },
                {
                    name: '🎛️ **Slash Commands**',
                    value: '• `/status` - View all title assignments\n' +
                           '• `/status [title]` - Check specific title\n' +
                           '• `/queue [title]` - View queue details\n' +
                           '• `/remove` - Leave all queues\n' +
                           '• `/remove [title]` - Leave specific queue\n' +
                           '• `/help` - Show this help message',
                    inline: false
                },
                {
                    name: '🛡️ **Admin Commands**',
                    value: '• `/force-assign` - Force assign titles\n' +
                           '• `/mark-assigned` - Confirm in-game assignment\n' +
                           '• `/assignment-guide` - Get assignment steps\n' +
                           '• `/pending-assignments` - View pending assignments\n' +
                           '• Requires Administrator permissions',
                    inline: false
                },
                {
                    name: '📋 **Features**',
                    value: '✅ Fully automated title assignment\n' +
                           '✅ Automatic queue management\n' +
                           '✅ Real-time notifications\n' +
                           '✅ Anti-spam cooldowns\n' +
                           '✅ Zero admin intervention needed\n' +
                           '✅ Instant title activation',
                    inline: false
                }
            )
            .setFooter({ 
                text: 'RoK Title Bot v1.0 | Made for efficient kingdom management' 
            })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};