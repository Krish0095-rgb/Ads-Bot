const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config/config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mark-assigned')
        .setDescription('[ADMIN] Mark a title as assigned in-game')
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Title that was assigned in-game')
                .setRequired(true)
                .addChoices(
                    ...config.availableTitles.map(title => ({ name: title, value: title }))
                )
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction, titleManager) {
        // Check if user has admin permissions
        const hasAdminRole = interaction.member.roles.cache.some(role => 
            config.permissions.adminRoles.includes(role.id)
        );
        const isSuperAdmin = config.permissions.superAdmins.includes(interaction.user.id);
        const hasDiscordAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);

        if (!hasAdminRole && !isSuperAdmin && !hasDiscordAdmin) {
            return await interaction.reply({ 
                content: config.messages.noPermission, 
                ephemeral: true 
            });
        }

        const titleName = interaction.options.getString('title');
        const assignment = titleManager.titles.get(titleName);

        if (!assignment) {
            return await interaction.reply({ 
                content: `❌ No active assignment found for ${titleName}`, 
                ephemeral: true 
            });
        }

        if (assignment.gameAssigned) {
            return await interaction.reply({ 
                content: `ℹ️ ${titleName} is already marked as assigned in-game`, 
                ephemeral: true 
            });
        }

        // Mark as assigned in-game
        const success = titleManager.markGameAssigned(titleName);

        if (success) {
            const embed = new EmbedBuilder()
                .setColor(config.colors.success)
                .setTitle('✅ Title Confirmed In-Game')
                .setDescription(`**${titleName}** has been confirmed as assigned in Rise of Kingdoms`)
                .addFields(
                    { name: 'Governor', value: assignment.username, inline: true },
                    { name: 'Coordinates', value: assignment.coordinates, inline: true },
                    { name: 'Duration', value: `${assignment.duration} minutes`, inline: true },
                    { name: 'Confirmed By', value: `<@${interaction.user.id}>`, inline: true }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

            // Notify the user that their title is now active
            try {
                const user = await interaction.client.users.fetch(assignment.userId);
                const dmEmbed = new EmbedBuilder()
                    .setColor(config.colors.success)
                    .setTitle('🎮 Your Title is Now Active!')
                    .setDescription(`Your **${titleName}** title has been assigned in Rise of Kingdoms`)
                    .addFields(
                        { name: 'Location', value: assignment.coordinates, inline: true },
                        { name: 'Duration', value: `${assignment.duration} minutes`, inline: true }
                    )
                    .setFooter({ text: 'You can now use your title benefits in-game!' })
                    .setTimestamp();

                await user.send({ embeds: [dmEmbed] });
            } catch (error) {
                console.log('Could not send DM to user:', error.message);
            }

            console.log(`✅ GAME ASSIGNED: ${titleName} confirmed in-game for ${assignment.username}`);
        } else {
            await interaction.reply({ 
                content: '❌ Failed to mark title as assigned. Please try again.', 
                ephemeral: true 
            });
        }
    }
};