const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config/config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('pending-assignments')
        .setDescription('[ADMIN] View all titles pending in-game assignment')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction, titleManager) {
        // Check if user has admin permissions
        const hasAdminRole = interaction.member.roles.cache.some(role => 
            config.permissions.adminRoles.includes(role.id)
        );
        const isSuperAdmin = config.permissions.superAdmins.includes(interaction.user.id);
        const hasDiscordAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);

        if (!hasAdminRole && !isSuperAdmin && !hasDiscordAdmin) {
            return await interaction.reply({ 
                content: config.messages.noPermission, 
                ephemeral: true 
            });
        }

        const pendingAssignments = [];
        const activeAssignments = [];

        for (const [titleName, assignment] of titleManager.titles) {
            if (assignment && !titleManager.isAssignmentExpired(assignment)) {
                if (!assignment.gameAssigned) {
                    pendingAssignments.push({ titleName, assignment });
                } else {
                    activeAssignments.push({ titleName, assignment });
                }
            }
        }

        const embed = new EmbedBuilder()
            .setColor(pendingAssignments.length > 0 ? config.colors.warning : config.colors.success)
            .setTitle('🎮 Title Assignment Status')
            .setDescription('Overview of all title assignments and their in-game status')
            .setTimestamp();

        if (pendingAssignments.length > 0) {
            let pendingText = '';
            pendingAssignments.forEach(({ titleName, assignment }) => {
                const timeRemaining = titleManager.getTimeRemaining(assignment);
                pendingText += `**${titleName}**\n`;
                pendingText += `👤 ${assignment.username}\n`;
                pendingText += `📍 ${assignment.coordinates}\n`;
                pendingText += `⏰ ${timeRemaining}min remaining\n\n`;
            });

            embed.addFields({
                name: '⚠️ Pending In-Game Assignment',
                value: pendingText.trim() || 'None',
                inline: false
            });
        }

        if (activeAssignments.length > 0) {
            let activeText = '';
            activeAssignments.forEach(({ titleName, assignment }) => {
                const timeRemaining = titleManager.getTimeRemaining(assignment);
                activeText += `✅ **${titleName}** - ${assignment.username} (${timeRemaining}min)\n`;
            });

            embed.addFields({
                name: '✅ Active In-Game',
                value: activeText.trim() || 'None',
                inline: false
            });
        }

        if (pendingAssignments.length === 0 && activeAssignments.length === 0) {
            embed.addFields({
                name: 'Status',
                value: 'No active title assignments',
                inline: false
            });
        }

        embed.addFields({
            name: '🛠️ Quick Actions',
            value: '• `/assignment-guide [title]` - Get assignment steps\n' +
                   '• `/mark-assigned [title]` - Confirm in-game assignment\n' +
                   '• `/force-assign` - Override current assignments',
            inline: false
        });

        await interaction.reply({ embeds: [embed] });
    }
};