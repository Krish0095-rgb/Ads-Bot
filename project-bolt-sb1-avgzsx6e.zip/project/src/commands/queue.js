const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config/config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('queue')
        .setDescription('View queue details for a specific title')
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Title to check queue for')
                .setRequired(true)
                .addChoices(
                    ...config.availableTitles.map(title => ({ name: title, value: title }))
                )
        ),

    async execute(interaction, titleManager) {
        const titleName = interaction.options.getString('title');
        const queue = titleManager.queues.get(titleName);
        const currentAssignment = titleManager.titles.get(titleName);

        if (!queue) {
            return await interaction.reply({ 
                content: '❌ Title not found.', 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setColor(config.colors.queue)
            .setTitle(`📋 ${titleName} Queue`)
            .setTimestamp();

        // Current assignment info
        if (currentAssignment && !titleManager.isAssignmentExpired(currentAssignment)) {
            const timeRemaining = titleManager.getTimeRemaining(currentAssignment);
            embed.addFields({
                name: '👑 Currently Assigned',
                value: `**${currentAssignment.username}**\n` +
                       `📍 ${currentAssignment.coordinates}\n` +
                       `⏰ ${timeRemaining} minutes remaining`,
                inline: false
            });
        } else {
            embed.addFields({
                name: '👑 Currently Assigned',
                value: '✅ Available',
                inline: false
            });
        }

        // Queue information
        if (queue.length === 0) {
            embed.addFields({
                name: '📝 Queue',
                value: 'No users in queue',
                inline: false
            });
        } else {
            let queueText = '';
            let totalWaitTime = currentAssignment ? titleManager.getTimeRemaining(currentAssignment) : 0;

            queue.forEach((request, index) => {
                const waitTime = index === 0 ? totalWaitTime : totalWaitTime;
                queueText += `**${index + 1}.** ${request.username}\n`;
                queueText += `   📍 ${request.coordinates} • ⏱️ ${request.duration}min\n`;
                queueText += `   🕐 ~${Math.round(waitTime)}min wait\n\n`;
                
                totalWaitTime += request.duration;
            });

            // Split long queue into multiple fields if needed
            if (queueText.length > 1024) {
                const chunks = queueText.match(/.{1,1000}(?=\n\n|$)/g) || [queueText];
                chunks.forEach((chunk, index) => {
                    embed.addFields({
                        name: index === 0 ? '📝 Queue' : '📝 Queue (continued)',
                        value: chunk.trim(),
                        inline: false
                    });
                });
            } else {
                embed.addFields({
                    name: '📝 Queue',
                    value: queueText.trim(),
                    inline: false
                });
            }

            embed.addFields({
                name: '📊 Queue Stats',
                value: `**Total Queued:** ${queue.length}\n` +
                       `**Est. Total Wait:** ~${Math.round(totalWaitTime)}min`,
                inline: true
            });
        }

        embed.setFooter({ 
            text: `Use "Can I get ${titleName} at [coordinates] for [duration]" to join queue` 
        });

        await interaction.reply({ embeds: [embed] });
    }
};