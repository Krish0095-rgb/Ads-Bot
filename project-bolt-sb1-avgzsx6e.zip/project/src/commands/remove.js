const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config/config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove')
        .setDescription('Remove yourself from title queues')
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Title queue to leave (leave empty to leave all queues)')
                .setRequired(false)
                .addChoices(
                    ...config.availableTitles.map(title => ({ name: title, value: title }))
                )
        ),

    async execute(interaction, titleManager) {
        const specificTitle = interaction.options.getString('title');
        const userId = interaction.user.id;
        let removedCount = 0;
        let removedFrom = [];

        if (specificTitle) {
            // Remove from specific title queue
            const queue = titleManager.queues.get(specificTitle);
            if (queue) {
                const initialLength = queue.length;
                const filteredQueue = queue.filter(req => req.userId !== userId);
                
                if (filteredQueue.length < initialLength) {
                    titleManager.queues.set(specificTitle, filteredQueue);
                    removedCount = 1;
                    removedFrom.push(specificTitle);
                }
            }
        } else {
            // Remove from all queues
            for (const [titleName, queue] of titleManager.queues) {
                const initialLength = queue.length;
                const filteredQueue = queue.filter(req => req.userId !== userId);
                
                if (filteredQueue.length < initialLength) {
                    titleManager.queues.set(titleName, filteredQueue);
                    removedCount++;
                    removedFrom.push(titleName);
                }
            }
        }

        const embed = new EmbedBuilder()
            .setColor(removedCount > 0 ? config.colors.success : config.colors.warning)
            .setTitle('📤 Queue Removal')
            .setTimestamp();

        if (removedCount > 0) {
            embed.setDescription(`✅ Removed from ${removedCount} queue${removedCount > 1 ? 's' : ''}`);
            
            if (removedFrom.length > 0) {
                embed.addFields({
                    name: 'Removed From',
                    value: removedFrom.join('\n'),
                    inline: false
                });
            }
        } else {
            embed.setDescription('ℹ️ You were not in any queues');
            
            if (specificTitle) {
                embed.addFields({
                    name: 'Note',
                    value: `You were not in the ${specificTitle} queue`,
                    inline: false
                });
            }
        }

        await interaction.reply({ embeds: [embed] });
    }
};