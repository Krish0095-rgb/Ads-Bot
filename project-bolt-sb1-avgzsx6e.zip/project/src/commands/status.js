const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const moment = require('moment');
const config = require('../config/config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('status')
        .setDescription('View current title assignments and queue status')
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Specific title to check (optional)')
                .setRequired(false)
                .addChoices(
                    ...config.availableTitles.map(title => ({ name: title, value: title }))
                )
        ),

    async execute(interaction, titleManager) {
        const specificTitle = interaction.options.getString('title');
        const status = titleManager.getAllTitleStatus();

        if (specificTitle) {
            // Show detailed status for specific title
            const titleStatus = status[specificTitle];
            if (!titleStatus) {
                return await interaction.reply({ content: '❌ Title not found.', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setColor(titleStatus.available ? config.colors.success : config.colors.warning)
                .setTitle(`🏰 ${specificTitle} Status`)
                .setTimestamp();

            if (titleStatus.available) {
                embed.setDescription('✅ **Available for Immediate Assignment**')
                    .addFields({ name: 'Status', value: 'Ready for automatic assignment', inline: true });
            } else {
                embed.setDescription(`🎮 **Active - Assigned to ${titleStatus.currentUser}**`)
                    .addFields(
                        { name: 'Coordinates', value: titleStatus.coordinates, inline: true },
                        { name: 'Time Remaining', value: `${titleStatus.timeRemaining} minutes`, inline: true },
                        { name: 'Queue Length', value: titleStatus.queueLength.toString(), inline: true }
                    );
            }

            if (titleStatus.queueLength > 0) {
                embed.addFields({ name: 'Queue', value: `${titleStatus.queueLength} users waiting`, inline: true });
            }

            await interaction.reply({ embeds: [embed] });
        } else {
            // Show overview of all titles
            const embed = new EmbedBuilder()
                .setColor(config.colors.info)
                .setTitle('🏰 All Title Status')
                .setDescription('Current assignment status - All titles are automatically managed!')
                .setTimestamp();

            const availableTitles = [];
            const inUseTitles = [];

            for (const [title, titleStatus] of Object.entries(status)) {
                if (titleStatus.available) {
                    availableTitles.push(`✅ ${title} - Ready for instant assignment`);
                } else {
                    const queueInfo = titleStatus.queueLength > 0 ? ` (${titleStatus.queueLength} queued)` : '';
                    inUseTitles.push(`🎮 ${title} - ${titleStatus.timeRemaining}m remaining${queueInfo}`);
                }
            }

            if (availableTitles.length > 0) {
                embed.addFields({ 
                    name: 'Available Titles', 
                    value: availableTitles.join('\n') || 'None', 
                    inline: false 
                });
            }

            if (inUseTitles.length > 0) {
                embed.addFields({ 
                    name: 'In Use', 
                    value: inUseTitles.join('\n') || 'None', 
                    inline: false 
                });
            }

            embed.addFields({ 
                name: 'Usage', 
                value: 'All titles are automatically assigned and managed - no admin intervention needed!', 
                inline: false 
            });

            await interaction.reply({ embeds: [embed] });
        }
    }
};