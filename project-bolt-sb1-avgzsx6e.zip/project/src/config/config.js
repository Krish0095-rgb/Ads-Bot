module.exports = {
    // Available RoK titles that can be managed
    availableTitles: [
        'Scientist',
        'Architect', 
        'General',
        'Duke',
        'Prime Minister',
        'Foreign Minister',
        'Interior Minister',
        'Agriculture Minister',
        'Economist',
        'Chief of Staff',
        'Messenger',
        'Strategist'
    ],

    // Bot settings
    defaultTitleDuration: 15, // minutes
    maxTitleDuration: 180,    // 3 hours max
    minTitleDuration: 5,      // 5 minutes min
    maxQueueSize: 10,         // Max users in queue per title
    userCooldownMinutes: 5,   // Cooldown between requests

    // Colors for embeds
    colors: {
        success: '#00ff00',
        warning: '#ffaa00', 
        error: '#ff0000',
        info: '#0099ff',
        queue: '#9932cc'
    },

    // Permissions
    permissions: {
        // Discord role IDs that can use admin commands
        adminRoles: ['123456789012345678'], // Replace with actual role IDs
        modRoles: ['123456789012345678'],   // Replace with actual role IDs
        
        // User IDs with special permissions
        superAdmins: ['123456789012345678'] // Replace with actual user IDs
    },

    // Features
    features: {
        enableCooldowns: true,
        enableQueueLimit: true,
        enableAutoAssignment: true,
        enableNotifications: true,
        logAllRequests: true
    },

    // Messages
    messages: {
        noPermission: '❌ You don\'t have permission to use this command.',
        invalidTitle: '❌ Invalid title. Use `/status` to see available titles.',
        cooldownActive: '⏰ You must wait {time} before making another request.',
        queueFull: '❌ The queue for {title} is full. Try again later.',
        titleAssigned: '✅ {title} assigned to {user} for {duration} minutes.',
        addedToQueue: '⏳ Added to {title} queue. Position: #{position}, Estimated wait: {wait}'
    }
};