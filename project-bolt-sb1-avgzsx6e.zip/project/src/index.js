const { Client, GatewayIntentBits, EmbedBuilder, Collection } = require('discord.js');
const TitleManager = require('./managers/TitleManager');
const MessageParser = require('./utils/MessageParser');
const config = require('./config/config');
require('dotenv').config();

class RoKTitleBot {
    constructor() {
        this.client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent,
                GatewayIntentBits.GuildMembers
            ]
        });
        
        this.titleManager = new TitleManager();
        this.messageParser = new MessageParser();
        this.commands = new Collection();
        
        this.setupTitleManagerCallbacks();
        this.setupEventListeners();
        this.loadCommands();
    }

    setupTitleManagerCallbacks() {
        // Set up automatic reassignment notifications
        this.titleManager.setAutoReassignmentCallback(async (titleName, assignment) => {
            await this.sendAutoReassignmentNotification(titleName, assignment);
        });

        // Set up title availability notifications
        this.titleManager.setTitleAvailableCallback(async (titleName) => {
            await this.sendTitleAvailableNotification(titleName);
        });
    }

    async sendAutoReassignmentNotification(titleName, assignment) {
        try {
            const channel = await this.client.channels.fetch(process.env.TITLE_REQUEST_CHANNEL_ID);
            
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🔄 Automatic Title Reassignment')
                .setDescription(`**${titleName}** has been automatically reassigned!`)
                .addFields(
                    { name: 'New Assignee', value: `<@${assignment.userId}>`, inline: true },
                    { name: 'Coordinates', value: assignment.coordinates, inline: true },
                    { name: 'Duration', value: `${assignment.duration} minutes`, inline: true }
                )
                .addFields({
                    name: '✅ Status',
                    value: 'Title is now active and ready to use in-game!',
                    inline: false
                })
                .setTimestamp();
            
            await channel.send({ embeds: [embed] });

            // Send DM to the new assignee
            try {
                const user = await this.client.users.fetch(assignment.userId);
                const dmEmbed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('🎉 Your Title is Ready!')
                    .setDescription(`You've been assigned **${titleName}**!`)
                    .addFields(
                        { name: 'Location', value: assignment.coordinates, inline: true },
                        { name: 'Duration', value: `${assignment.duration} minutes`, inline: true }
                    )
                    .setFooter({ text: 'Your title is now active and ready to use!' })
                    .setTimestamp();

                await user.send({ embeds: [dmEmbed] });
            } catch (error) {
                console.log('Could not send DM to user:', error.message);
            }
        } catch (error) {
            console.error('Error sending auto-reassignment notification:', error);
        }
    }

    async sendTitleAvailableNotification(titleName) {
        try {
            const channel = await this.client.channels.fetch(process.env.TITLE_REQUEST_CHANNEL_ID);
            
            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Title Now Available')
                .setDescription(`**${titleName}** is now available for assignment!`)
                .addFields({
                    name: '📝 How to Request',
                    value: `Send a message like: "Can I get ${titleName} at [coordinates] for [duration]?"`,
                    inline: false
                })
                .setTimestamp();
            
            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error sending title available notification:', error);
        }
    }
    setupEventListeners() {
        this.client.once('ready', () => {
            console.log(`🚀 ${this.client.user.tag} is now online!`);
            console.log(`📊 Monitoring channel: ${process.env.TITLE_REQUEST_CHANNEL_ID}`);
            this.client.user.setActivity('RoK Title Management', { type: 'WATCHING' });
        });

        this.client.on('messageCreate', async (message) => {
            await this.handleMessage(message);
        });

        this.client.on('interactionCreate', async (interaction) => {
            if (!interaction.isChatInputCommand()) return;
            await this.handleSlashCommand(interaction);
        });
    }

    async handleMessage(message) {
        // Ignore bot messages and messages not in the designated channel
        if (message.author.bot) return;
        if (message.channel.id !== process.env.TITLE_REQUEST_CHANNEL_ID) return;

        try {
            const parsedRequest = this.messageParser.parseRequest(message.content);
            
            if (parsedRequest) {
                await this.processTitleRequest(message, parsedRequest);
            }
        } catch (error) {
            console.error('Error handling message:', error);
            await message.reply('❌ Sorry, there was an error processing your request.');
        }
    }

    async processTitleRequest(message, request) {
        const { title, coordinates, duration } = request;
        const user = message.author;
        
        console.log(`📝 Title request: ${title} by ${user.username} for ${duration} minutes at ${coordinates}`);

        const result = await this.titleManager.requestTitle(user.id, title, coordinates, duration, user.username);
        
        const embed = new EmbedBuilder()
            .setColor(result.success ? '#00ff00' : '#ffaa00')
            .setTitle(`🏰 ${title} Title Request`)
            .setAuthor({ name: user.username, iconURL: user.displayAvatarURL() })
            .addFields({ name: 'Coordinates', value: coordinates, inline: true })
            .setTimestamp();

        if (result.success) {
            embed.setDescription(`✅ **${title}** title assigned and activated automatically!`)
                .addFields(
                    { name: 'Duration', value: `${duration} minutes`, inline: true },
                    { name: 'Status', value: '🎮 Active & Ready to Use!', inline: true }
                )
                .addFields({
                    name: '🎉 You\'re All Set!',
                    value: `Your **${title}** title is now active at coordinates **${coordinates}**!\n` +
                           `The title will automatically expire in ${duration} minutes.`,
                    inline: false
                });
        } else {
            if (result.reason === 'queue_full') {
                embed.setColor('#ff0000')
                    .setDescription(`❌ **${title}** queue is full (${config.maxQueueSize} users maximum)`)
                    .addFields({
                        name: '⏰ Try Again Later',
                        value: 'Please wait for the queue to clear and try your request again.',
                        inline: false
                    });
            } else {
                embed.setDescription(`⏳ **${title}** is currently in use. You've been added to the queue.`)
                    .addFields(
                        { name: 'Queue Position', value: `#${result.queuePosition}`, inline: true },
                        { name: 'Estimated Wait', value: result.estimatedWait, inline: true }
                    )
                    .addFields({
                        name: '🔄 Automatic Assignment',
                        value: 'You\'ll be automatically assigned when the title becomes available!',
                        inline: false
                    });
            }
        }

        await message.reply({ embeds: [embed] });
    }

    async handleSlashCommand(interaction) {
        const command = this.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction, this.titleManager);
        } catch (error) {
            console.error('Slash command error:', error);
            const reply = { content: 'There was an error executing this command!', ephemeral: true };
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(reply);
            } else {
                await interaction.reply(reply);
            }
        }
    }

    loadCommands() {
        const commands = [
            require('./commands/status'),
            require('./commands/queue'),
            require('./commands/remove'),
            require('./commands/force-assign'),
            require('./commands/mark-assigned'),
            require('./commands/assignment-guide'),
            require('./commands/pending-assignments'),
            require('./commands/help')
        ];

        for (const command of commands) {
            this.commands.set(command.data.name, command);
        }
    }

    async start() {
        try {
            await this.client.login(process.env.DISCORD_TOKEN);
        } catch (error) {
            console.error('Failed to start bot:', error);
            process.exit(1);
        }
    }
}

// Start the bot
const bot = new RoKTitleBot();
bot.start();

module.exports = RoKTitleBot;