const moment = require('moment');
const config = require('../config/config');

class TitleManager {
    constructor() {
        this.titles = new Map(); // title -> { userId, username, coordinates, duration, assignedAt }
        this.queues = new Map(); // title -> [{ userId, username, coordinates, duration, requestedAt }]
        this.userCooldowns = new Map(); // userId -> lastRequestTime
        
        // Initialize available titles
        config.availableTitles.forEach(title => {
            this.titles.set(title, null);
            this.queues.set(title, []);
        });
    }

    async requestTitle(userId, titleName, coordinates, duration, username) {
        // Check cooldown
        if (this.isUserOnCooldown(userId)) {
            return {
                success: false,
                reason: 'cooldown',
                cooldownRemaining: this.getCooldownRemaining(userId)
            };
        }

        // Validate title exists
        if (!this.titles.has(titleName)) {
            return {
                success: false,
                reason: 'invalid_title',
                availableTitles: Array.from(this.titles.keys())
            };
        }

        // Check if title is available
        const currentAssignment = this.titles.get(titleName);
        
        if (!currentAssignment || this.isAssignmentExpired(currentAssignment)) {
            // Title is available, assign immediately
            this.assignTitle(titleName, userId, username, coordinates, duration);
            this.setUserCooldown(userId);
            
            return {
                success: true,
                assigned: true,
                title: titleName,
                coordinates,
                duration
            };
        } else {
            // Title is in use, add to queue
            const queuePosition = this.addToQueue(titleName, userId, username, coordinates, duration);
            
            if (queuePosition === null) {
                return {
                    success: false,
                    reason: 'queue_full',
                    title: titleName
                };
            }
            
            const estimatedWait = this.calculateEstimatedWait(titleName, queuePosition);
            
            return {
                success: false,
                queued: true,
                queuePosition,
                estimatedWait,
                title: titleName
            };
        }
    }

    assignTitle(titleName, userId, username, coordinates, duration) {
        const assignment = {
            userId,
            username,
            coordinates,
            duration,
            assignedAt: new Date(),
            gameAssigned: true, // Auto-assigned, no manual intervention needed
            reminderSent: false
        };
        
        this.titles.set(titleName, assignment);
        console.log(`✅ Assigned ${titleName} to ${username} (${userId}) for ${duration} minutes`);
        
        // Schedule automatic expiration and reassignment
        this.scheduleAutoExpiration(titleName, duration);
    }

    scheduleAutoExpiration(titleName, duration) {
        setTimeout(async () => {
            const nextAssignment = await this.processExpiration(titleName);
            
            if (nextAssignment) {
                console.log(`🔄 Auto-reassigned ${titleName} to ${nextAssignment.username}`);
                
                // Emit event for notification
                if (this.onAutoReassignment) {
                    this.onAutoReassignment(titleName, nextAssignment);
                }
                
                // Schedule next expiration
                this.scheduleAutoExpiration(titleName, nextAssignment.duration);
            } else {
                console.log(`📤 ${titleName} is now available (no queue)`);
                
                // Emit event for availability notification
                if (this.onTitleAvailable) {
                    this.onTitleAvailable(titleName);
                }
            }
        }, duration * 60 * 1000);
    }

    // Set callback for auto-reassignment notifications
    setAutoReassignmentCallback(callback) {
        this.onAutoReassignment = callback;
    }

    // Set callback for title availability notifications
    setTitleAvailableCallback(callback) {
        this.onTitleAvailable = callback;
    }

    markGameAssigned(titleName) {
        const assignment = this.titles.get(titleName);
        if (assignment) {
            // Already auto-assigned, but keep for compatibility
            this.titles.set(titleName, assignment);
            return true;
        }
        return false;
    }

    getAssignmentInstructions(titleName) {
        const assignment = this.titles.get(titleName);
        if (!assignment) return null;

        return {
            title: titleName,
            username: assignment.username,
            coordinates: assignment.coordinates,
            duration: assignment.duration,
            steps: [
                "1. Open Rise of Kingdoms",
                "2. Go to Kingdom Map",
                `3. Navigate to coordinates ${assignment.coordinates}`,
                "4. Tap on the city/structure",
                "5. Select 'Appoint' or 'Title'",
                `6. Choose '${titleName}' title`,
                `7. Search for governor: ${assignment.username}`,
                "8. Confirm appointment",
                `9. Set duration: ${assignment.duration} minutes`
            ]
        };
    }

    addToQueue(titleName, userId, username, coordinates, duration) {
        const queue = this.queues.get(titleName);
        
        // Check if queue is at maximum capacity
        if (queue.length >= config.maxQueueSize) {
            return null; // Queue is full
        }
        
        // Check if user is already in queue
        const existingIndex = queue.findIndex(req => req.userId === userId);
        if (existingIndex !== -1) {
            // Update existing request
            queue[existingIndex] = { userId, username, coordinates, duration, requestedAt: new Date() };
            return existingIndex + 1;
        } else {
            // Add new request
            queue.push({ userId, username, coordinates, duration, requestedAt: new Date() });
            this.queues.set(titleName, queue);
            return queue.length;
        }
    }

    async processExpiration(titleName) {
        const currentAssignment = this.titles.get(titleName);
        
        if (currentAssignment && this.isAssignmentExpired(currentAssignment)) {
            // Clear current assignment
            this.titles.set(titleName, null);
            console.log(`⏰ ${titleName} assignment expired for ${currentAssignment.username}`);
        }

        // Check queue for next assignment
        const queue = this.queues.get(titleName);
        if (queue && queue.length > 0) {
            const nextRequest = queue.shift();
            this.assignTitle(titleName, nextRequest.userId, nextRequest.username, nextRequest.coordinates, nextRequest.duration);
            this.queues.set(titleName, queue);
            
            return {
                userId: nextRequest.userId,
                username: nextRequest.username,
                coordinates: nextRequest.coordinates,
                duration: nextRequest.duration,
                title: titleName
            };
        }
        
        return null;
    }

    isAssignmentExpired(assignment) {
        if (!assignment) return true;
        
        const expiredAt = moment(assignment.assignedAt).add(assignment.duration, 'minutes');
        return moment().isAfter(expiredAt);
    }

    isUserOnCooldown(userId) {
        const lastRequest = this.userCooldowns.get(userId);
        if (!lastRequest) return false;
        
        const cooldownEnds = moment(lastRequest).add(config.userCooldownMinutes, 'minutes');
        return moment().isBefore(cooldownEnds);
    }

    getCooldownRemaining(userId) {
        const lastRequest = this.userCooldowns.get(userId);
        if (!lastRequest) return 0;
        
        const cooldownEnds = moment(lastRequest).add(config.userCooldownMinutes, 'minutes');
        return Math.max(0, cooldownEnds.diff(moment(), 'minutes'));
    }

    setUserCooldown(userId) {
        this.userCooldowns.set(userId, new Date());
    }

    calculateEstimatedWait(titleName, queuePosition) {
        const currentAssignment = this.titles.get(titleName);
        if (!currentAssignment) return "0 minutes";
        
        const timeRemaining = moment(currentAssignment.assignedAt)
            .add(currentAssignment.duration, 'minutes')
            .diff(moment(), 'minutes');
        
        const queue = this.queues.get(titleName);
        let totalWait = Math.max(0, timeRemaining);
        
        // Add estimated time for users ahead in queue
        for (let i = 0; i < queuePosition - 1 && i < queue.length; i++) {
            totalWait += queue[i].duration;
        }
        
        return totalWait > 60 ? `${Math.round(totalWait / 60)} hours` : `${totalWait} minutes`;
    }

    getAllTitleStatus() {
        const status = {};
        
        for (const [titleName, assignment] of this.titles) {
            const queue = this.queues.get(titleName);
            
            status[titleName] = {
                available: !assignment || this.isAssignmentExpired(assignment),
                currentUser: assignment ? assignment.username : null,
                timeRemaining: assignment ? this.getTimeRemaining(assignment) : null,
                queueLength: queue.length,
                coordinates: assignment ? assignment.coordinates : null
            };
        }
        
        return status;
    }

    getTimeRemaining(assignment) {
        if (!assignment) return 0;
        
        const expiredAt = moment(assignment.assignedAt).add(assignment.duration, 'minutes');
        return Math.max(0, expiredAt.diff(moment(), 'minutes'));
    }

    removeUserFromAllQueues(userId) {
        let removedCount = 0;
        
        for (const [titleName, queue] of this.queues) {
            const initialLength = queue.length;
            const filteredQueue = queue.filter(req => req.userId !== userId);
            
            if (filteredQueue.length < initialLength) {
                this.queues.set(titleName, filteredQueue);
                removedCount++;
            }
        }
        
        return removedCount;
    }

    forceAssignTitle(titleName, userId, username, coordinates, duration) {
        // Clear any existing assignment
        this.titles.set(titleName, null);
        
        // Clear user from all queues
        this.removeUserFromAllQueues(userId);
        
        // Assign title
        this.assignTitle(titleName, userId, username, coordinates, duration);
        
        return true;
    }
}

module.exports = TitleManager;