class MessageParser {
    constructor() {
        // Regex patterns for parsing different message formats
        this.patterns = {
            // Coordinates patterns
            coordinates: [
                /(?:x[:\s]*(\d{1,4})[,\s]*y[:\s]*(\d{1,4}))/i,  // x:1234 y:567 or x1234 y567
                /(?:(\d{1,4})[,\s]+(\d{1,4}))/,                   // 1234 567 or 1234,567
                /(?:coords?[:\s]*(\d{1,4})[,\s]*(\d{1,4}))/i      // coords: 1234 567
            ],
            
            // Duration patterns
            duration: [
                /(\d+)\s*(?:minutes?|mins?|m)\b/i,               // 15 minutes, 10 min, 20m
                /(?:for\s+)?(\d+)\s*(?:minutes?|mins?|m)\b/i,    // for 15 minutes
                /(\d+)['′]\s*(?:minutes?|mins?|m)?/i             // 15' or 15′
            ],
            
            // Title patterns - common RoK titles
            titles: [
                'scientist', 'architect', 'general', 'duke', 'prime minister', 
                'foreign minister', 'interior minister', 'agriculture minister',
                'economist', 'chief of staff', 'messenger', 'strategist'
            ]
        };
    }

    parseRequest(message) {
        const lowerMessage = message.toLowerCase();
        
        // Check if this looks like a title request
        if (!this.isLikelyTitleRequest(lowerMessage)) {
            return null;
        }

        const title = this.extractTitle(lowerMessage);
        const coordinates = this.extractCoordinates(message);
        const duration = this.extractDuration(lowerMessage);

        // Must have at least title and coordinates
        if (!title || !coordinates) {
            return null;
        }

        return {
            title: this.capitalizeTitle(title),
            coordinates,
            duration: duration || 15 // Default 15 minutes
        };
    }

    isLikelyTitleRequest(message) {
        const keywords = [
            'need', 'want', 'request', 'get', 'give', 'assign', 'title',
            'can i', 'could i', 'may i', 'please', 'pls'
        ];
        
        return keywords.some(keyword => message.includes(keyword)) ||
               this.patterns.titles.some(title => message.includes(title));
    }

    extractTitle(message) {
        // Look for title names in the message
        for (const title of this.patterns.titles) {
            if (message.includes(title)) {
                return title;
            }
        }
        
        // Try to extract title after common phrases
        const titlePatterns = [
            /(?:need|want|request|get)\s+(\w+(?:\s+\w+)?)/i,
            /(\w+(?:\s+\w+)?)\s+(?:title|at)/i
        ];
        
        for (const pattern of titlePatterns) {
            const match = message.match(pattern);
            if (match && this.isValidTitle(match[1].toLowerCase())) {
                return match[1].toLowerCase();
            }
        }
        
        return null;
    }

    extractCoordinates(message) {
        for (const pattern of this.patterns.coordinates) {
            const match = message.match(pattern);
            if (match) {
                const x = parseInt(match[1]);
                const y = parseInt(match[2]);
                
                // Validate coordinate ranges (RoK coordinates are typically 1-9999)
                if (x >= 1 && x <= 9999 && y >= 1 && y <= 9999) {
                    return `${x}, ${y}`;
                }
            }
        }
        return null;
    }

    extractDuration(message) {
        for (const pattern of this.patterns.duration) {
            const match = message.match(pattern);
            if (match) {
                const duration = parseInt(match[1]);
                // Validate duration (1-180 minutes)
                if (duration >= 1 && duration <= 180) {
                    return duration;
                }
            }
        }
        return null;
    }

    isValidTitle(title) {
        return this.patterns.titles.includes(title) || 
               title.split(' ').every(word => word.length >= 3);
    }

    capitalizeTitle(title) {
        return title.split(' ')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
    }

    // Test method for debugging
    testParse(message) {
        console.log(`Testing: "${message}"`);
        const result = this.parseRequest(message);
        console.log('Result:', result);
        return result;
    }
}

module.exports = MessageParser;